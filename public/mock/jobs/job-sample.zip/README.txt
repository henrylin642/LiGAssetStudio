Mock ZIP for batch job results.
